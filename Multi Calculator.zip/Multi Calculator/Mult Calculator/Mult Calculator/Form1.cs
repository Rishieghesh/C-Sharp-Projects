﻿using Mult_Calculator.Calculators;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Mult_Calculator
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void guna2Button7_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void btn_Data_Click(object sender, EventArgs e)
        {
            uC_dataCal1.Visible = true;
            uC_AreaCal1.Visible = false;
            uC_BMIcal1.Visible = false;
            uC_tempCal1.Visible = false;
            uC_weightCal1.Visible = false;
            uC_programmer1.Visible = false;
        }

        private void btn_Program_Click(object sender, EventArgs e)
        {
            uC_dataCal1.Visible = false;
            uC_AreaCal1.Visible = false;
            uC_BMIcal1.Visible = false;
            uC_tempCal1.Visible = false;
            uC_weightCal1.Visible = false;
            uC_programmer1.Visible = true;
        }

        private void btn_Temp_Click(object sender, EventArgs e)
        {
            uC_dataCal1.Visible = false;
            uC_AreaCal1.Visible = false;
            uC_BMIcal1.Visible = false;
            uC_tempCal1.Visible = true;
            uC_weightCal1.Visible = false;
            uC_programmer1.Visible = false;
        }

        private void btn_BMI_Click(object sender, EventArgs e)
        {
            uC_dataCal1.Visible = false;
            uC_AreaCal1.Visible = false;
            uC_BMIcal1.Visible = true;
            uC_tempCal1.Visible = false;
            uC_weightCal1.Visible = false;
            uC_programmer1.Visible = false;
        }

        private void btn_Weight_Click(object sender, EventArgs e)
        {
            uC_dataCal1.Visible = false;
            uC_AreaCal1.Visible = false;
            uC_BMIcal1.Visible = false;
            uC_tempCal1.Visible = false;
            uC_weightCal1.Visible = true;
            uC_programmer1.Visible = false;
        }

        private void btn_Area_Click(object sender, EventArgs e)
        {
            uC_dataCal1.Visible = false;
            uC_AreaCal1.Visible = true;
            uC_BMIcal1.Visible = false;
            uC_tempCal1.Visible = false;
            uC_weightCal1.Visible = false;
            uC_programmer1.Visible = false;
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            uC_dataCal1.Visible = false;
            uC_AreaCal1.Visible = false;
            uC_BMIcal1.Visible = false;
            uC_tempCal1.Visible = false;
            uC_weightCal1.Visible = false;
            uC_programmer1.Visible = false;
        }
    }
}
