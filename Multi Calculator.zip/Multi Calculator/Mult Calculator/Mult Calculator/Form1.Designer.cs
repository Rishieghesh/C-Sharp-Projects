﻿namespace Mult_Calculator
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.btn_Data = new Guna.UI2.WinForms.Guna2Button();
            this.panel2 = new System.Windows.Forms.Panel();
            this.guna2Panel1 = new Guna.UI2.WinForms.Guna2Panel();
            this.btn_BMI = new Guna.UI2.WinForms.Guna2Button();
            this.btn_Weight = new Guna.UI2.WinForms.Guna2Button();
            this.btn_Temp = new Guna.UI2.WinForms.Guna2Button();
            this.btn_Area = new Guna.UI2.WinForms.Guna2Button();
            this.btn_Program = new Guna.UI2.WinForms.Guna2Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.label1 = new System.Windows.Forms.Label();
            this.guna2Button7 = new Guna.UI2.WinForms.Guna2Button();
            this.Elipse_Data = new Guna.UI2.WinForms.Guna2Elipse(this.components);
            this.Elipse_Prog = new Guna.UI2.WinForms.Guna2Elipse(this.components);
            this.Elipse_BMI = new Guna.UI2.WinForms.Guna2Elipse(this.components);
            this.Elipse_temp = new Guna.UI2.WinForms.Guna2Elipse(this.components);
            this.Elipse_weight = new Guna.UI2.WinForms.Guna2Elipse(this.components);
            this.Elipse_Area = new Guna.UI2.WinForms.Guna2Elipse(this.components);
            this.uC_AreaCal1 = new Mult_Calculator.Calculators.uC_AreaCal();
            this.uC_dataCal1 = new Mult_Calculator.Calculators.uC_dataCal();
            this.uC_weightCal1 = new Mult_Calculator.Calculators.uC_weightCal();
            this.uC_BMIcal1 = new Mult_Calculator.Calculators.uC_BMIcal();
            this.uC_programmer1 = new Mult_Calculator.Calculators.uC_programmer();
            this.uC_tempCal1 = new Mult_Calculator.Calculators.uC_tempCal();
            this.panel2.SuspendLayout();
            this.guna2Panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // btn_Data
            // 
            this.btn_Data.BorderRadius = 18;
            this.btn_Data.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_Data.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.btn_Data.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.btn_Data.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.btn_Data.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.btn_Data.FillColor = System.Drawing.Color.Transparent;
            this.btn_Data.Font = new System.Drawing.Font("Segoe UI", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Data.ForeColor = System.Drawing.Color.White;
            this.btn_Data.Image = ((System.Drawing.Image)(resources.GetObject("btn_Data.Image")));
            this.btn_Data.ImageSize = new System.Drawing.Size(30, 30);
            this.btn_Data.Location = new System.Drawing.Point(0, 247);
            this.btn_Data.Name = "btn_Data";
            this.btn_Data.Size = new System.Drawing.Size(235, 45);
            this.btn_Data.TabIndex = 0;
            this.btn_Data.Text = "Data";
            this.btn_Data.Click += new System.EventHandler(this.btn_Data_Click);
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(241)))), ((int)(((byte)(246)))), ((int)(((byte)(249)))));
            this.panel2.Controls.Add(this.uC_tempCal1);
            this.panel2.Controls.Add(this.uC_programmer1);
            this.panel2.Controls.Add(this.uC_BMIcal1);
            this.panel2.Controls.Add(this.uC_weightCal1);
            this.panel2.Controls.Add(this.uC_dataCal1);
            this.panel2.Controls.Add(this.uC_AreaCal1);
            this.panel2.Location = new System.Drawing.Point(256, 12);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(1082, 693);
            this.panel2.TabIndex = 1;
            // 
            // guna2Panel1
            // 
            this.guna2Panel1.BackColor = System.Drawing.Color.Transparent;
            this.guna2Panel1.BorderColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.guna2Panel1.BorderRadius = 18;
            this.guna2Panel1.BorderStyle = System.Drawing.Drawing2D.DashStyle.Custom;
            this.guna2Panel1.Controls.Add(this.btn_BMI);
            this.guna2Panel1.Controls.Add(this.guna2Button7);
            this.guna2Panel1.Controls.Add(this.label1);
            this.guna2Panel1.Controls.Add(this.pictureBox1);
            this.guna2Panel1.Controls.Add(this.btn_Program);
            this.guna2Panel1.Controls.Add(this.btn_Area);
            this.guna2Panel1.Controls.Add(this.btn_Weight);
            this.guna2Panel1.Controls.Add(this.btn_Temp);
            this.guna2Panel1.Controls.Add(this.btn_Data);
            this.guna2Panel1.Location = new System.Drawing.Point(12, 12);
            this.guna2Panel1.Name = "guna2Panel1";
            this.guna2Panel1.Size = new System.Drawing.Size(238, 693);
            this.guna2Panel1.TabIndex = 2;
            // 
            // btn_BMI
            // 
            this.btn_BMI.BorderRadius = 18;
            this.btn_BMI.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_BMI.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.btn_BMI.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.btn_BMI.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.btn_BMI.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.btn_BMI.FillColor = System.Drawing.Color.Transparent;
            this.btn_BMI.Font = new System.Drawing.Font("Segoe UI", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_BMI.ForeColor = System.Drawing.Color.White;
            this.btn_BMI.Image = ((System.Drawing.Image)(resources.GetObject("btn_BMI.Image")));
            this.btn_BMI.ImageSize = new System.Drawing.Size(30, 30);
            this.btn_BMI.Location = new System.Drawing.Point(3, 400);
            this.btn_BMI.Name = "btn_BMI";
            this.btn_BMI.Size = new System.Drawing.Size(235, 45);
            this.btn_BMI.TabIndex = 1;
            this.btn_BMI.Text = "BMI Calculator";
            this.btn_BMI.Click += new System.EventHandler(this.btn_BMI_Click);
            // 
            // btn_Weight
            // 
            this.btn_Weight.BorderRadius = 18;
            this.btn_Weight.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_Weight.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.btn_Weight.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.btn_Weight.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.btn_Weight.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.btn_Weight.FillColor = System.Drawing.Color.Transparent;
            this.btn_Weight.Font = new System.Drawing.Font("Segoe UI", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Weight.ForeColor = System.Drawing.Color.White;
            this.btn_Weight.Image = ((System.Drawing.Image)(resources.GetObject("btn_Weight.Image")));
            this.btn_Weight.ImageSize = new System.Drawing.Size(30, 30);
            this.btn_Weight.Location = new System.Drawing.Point(0, 451);
            this.btn_Weight.Name = "btn_Weight";
            this.btn_Weight.Size = new System.Drawing.Size(235, 45);
            this.btn_Weight.TabIndex = 3;
            this.btn_Weight.Text = "Weight";
            this.btn_Weight.Click += new System.EventHandler(this.btn_Weight_Click);
            // 
            // btn_Temp
            // 
            this.btn_Temp.BorderRadius = 18;
            this.btn_Temp.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_Temp.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.btn_Temp.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.btn_Temp.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.btn_Temp.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.btn_Temp.FillColor = System.Drawing.Color.Transparent;
            this.btn_Temp.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Temp.ForeColor = System.Drawing.Color.White;
            this.btn_Temp.Image = ((System.Drawing.Image)(resources.GetObject("btn_Temp.Image")));
            this.btn_Temp.ImageSize = new System.Drawing.Size(30, 30);
            this.btn_Temp.Location = new System.Drawing.Point(0, 349);
            this.btn_Temp.Name = "btn_Temp";
            this.btn_Temp.Size = new System.Drawing.Size(235, 45);
            this.btn_Temp.TabIndex = 2;
            this.btn_Temp.Text = "Temperature";
            this.btn_Temp.Click += new System.EventHandler(this.btn_Temp_Click);
            // 
            // btn_Area
            // 
            this.btn_Area.BorderRadius = 18;
            this.btn_Area.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_Area.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.btn_Area.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.btn_Area.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.btn_Area.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.btn_Area.FillColor = System.Drawing.Color.Transparent;
            this.btn_Area.Font = new System.Drawing.Font("Segoe UI", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Area.ForeColor = System.Drawing.Color.White;
            this.btn_Area.Image = ((System.Drawing.Image)(resources.GetObject("btn_Area.Image")));
            this.btn_Area.ImageSize = new System.Drawing.Size(30, 30);
            this.btn_Area.Location = new System.Drawing.Point(0, 502);
            this.btn_Area.Name = "btn_Area";
            this.btn_Area.Size = new System.Drawing.Size(235, 45);
            this.btn_Area.TabIndex = 4;
            this.btn_Area.Text = "Area";
            this.btn_Area.Click += new System.EventHandler(this.btn_Area_Click);
            // 
            // btn_Program
            // 
            this.btn_Program.BorderRadius = 18;
            this.btn_Program.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_Program.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.btn_Program.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.btn_Program.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.btn_Program.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.btn_Program.FillColor = System.Drawing.Color.Transparent;
            this.btn_Program.Font = new System.Drawing.Font("Segoe UI", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Program.ForeColor = System.Drawing.Color.White;
            this.btn_Program.Image = ((System.Drawing.Image)(resources.GetObject("btn_Program.Image")));
            this.btn_Program.ImageSize = new System.Drawing.Size(30, 30);
            this.btn_Program.Location = new System.Drawing.Point(0, 298);
            this.btn_Program.Name = "btn_Program";
            this.btn_Program.Size = new System.Drawing.Size(235, 45);
            this.btn_Program.TabIndex = 5;
            this.btn_Program.Text = "Programmer";
            this.btn_Program.Click += new System.EventHandler(this.btn_Program_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(60, 16);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(118, 131);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 6;
            this.pictureBox1.TabStop = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.LemonChiffon;
            this.label1.Location = new System.Drawing.Point(19, 150);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(194, 29);
            this.label1.TabIndex = 7;
            this.label1.Text = "Multi Calculator";
            // 
            // guna2Button7
            // 
            this.guna2Button7.BorderColor = System.Drawing.Color.Transparent;
            this.guna2Button7.BorderRadius = 18;
            this.guna2Button7.BorderThickness = 2;
            this.guna2Button7.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.guna2Button7.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.guna2Button7.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.guna2Button7.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.guna2Button7.FillColor = System.Drawing.Color.Transparent;
            this.guna2Button7.Font = new System.Drawing.Font("Segoe UI", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2Button7.ForeColor = System.Drawing.Color.White;
            this.guna2Button7.Image = ((System.Drawing.Image)(resources.GetObject("guna2Button7.Image")));
            this.guna2Button7.ImageSize = new System.Drawing.Size(50, 50);
            this.guna2Button7.Location = new System.Drawing.Point(14, 594);
            this.guna2Button7.Name = "guna2Button7";
            this.guna2Button7.Size = new System.Drawing.Size(199, 96);
            this.guna2Button7.TabIndex = 8;
            this.guna2Button7.Text = "Exit";
            this.guna2Button7.Click += new System.EventHandler(this.guna2Button7_Click);
            // 
            // Elipse_Data
            // 
            this.Elipse_Data.TargetControl = this.panel2;
            // 
            // Elipse_Prog
            // 
            this.Elipse_Prog.TargetControl = this.panel2;
            // 
            // Elipse_BMI
            // 
            this.Elipse_BMI.TargetControl = this.panel2;
            // 
            // Elipse_temp
            // 
            this.Elipse_temp.TargetControl = this.panel2;
            // 
            // Elipse_weight
            // 
            this.Elipse_weight.TargetControl = this.panel2;
            // 
            // Elipse_Area
            // 
            this.Elipse_Area.TargetControl = this.panel2;
            // 
            // uC_AreaCal1
            // 
            this.uC_AreaCal1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(241)))), ((int)(((byte)(246)))), ((int)(((byte)(249)))));
            this.uC_AreaCal1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.uC_AreaCal1.Location = new System.Drawing.Point(0, 0);
            this.uC_AreaCal1.Name = "uC_AreaCal1";
            this.uC_AreaCal1.Size = new System.Drawing.Size(1082, 693);
            this.uC_AreaCal1.TabIndex = 0;
            // 
            // uC_dataCal1
            // 
            this.uC_dataCal1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(241)))), ((int)(((byte)(246)))), ((int)(((byte)(249)))));
            this.uC_dataCal1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.uC_dataCal1.Location = new System.Drawing.Point(0, 0);
            this.uC_dataCal1.Name = "uC_dataCal1";
            this.uC_dataCal1.Size = new System.Drawing.Size(1082, 693);
            this.uC_dataCal1.TabIndex = 1;
            // 
            // uC_weightCal1
            // 
            this.uC_weightCal1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(241)))), ((int)(((byte)(246)))), ((int)(((byte)(249)))));
            this.uC_weightCal1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.uC_weightCal1.Location = new System.Drawing.Point(0, 0);
            this.uC_weightCal1.Name = "uC_weightCal1";
            this.uC_weightCal1.Size = new System.Drawing.Size(1082, 693);
            this.uC_weightCal1.TabIndex = 2;
            // 
            // uC_BMIcal1
            // 
            this.uC_BMIcal1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(241)))), ((int)(((byte)(246)))), ((int)(((byte)(249)))));
            this.uC_BMIcal1.Location = new System.Drawing.Point(0, 0);
            this.uC_BMIcal1.Name = "uC_BMIcal1";
            this.uC_BMIcal1.Size = new System.Drawing.Size(1082, 693);
            this.uC_BMIcal1.TabIndex = 3;
            // 
            // uC_programmer1
            // 
            this.uC_programmer1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(241)))), ((int)(((byte)(246)))), ((int)(((byte)(249)))));
            this.uC_programmer1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.uC_programmer1.Location = new System.Drawing.Point(0, 0);
            this.uC_programmer1.Name = "uC_programmer1";
            this.uC_programmer1.Size = new System.Drawing.Size(1082, 693);
            this.uC_programmer1.TabIndex = 4;
            // 
            // uC_tempCal1
            // 
            this.uC_tempCal1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(241)))), ((int)(((byte)(246)))), ((int)(((byte)(249)))));
            this.uC_tempCal1.Location = new System.Drawing.Point(0, 0);
            this.uC_tempCal1.Name = "uC_tempCal1";
            this.uC_tempCal1.Size = new System.Drawing.Size(1082, 693);
            this.uC_tempCal1.TabIndex = 5;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(57)))), ((int)(((byte)(72)))), ((int)(((byte)(103)))));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(1350, 729);
            this.Controls.Add(this.guna2Panel1);
            this.Controls.Add(this.panel2);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.panel2.ResumeLayout(false);
            this.guna2Panel1.ResumeLayout(false);
            this.guna2Panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private Guna.UI2.WinForms.Guna2Button btn_Data;
        private System.Windows.Forms.Panel panel2;
        private Guna.UI2.WinForms.Guna2Panel guna2Panel1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private Guna.UI2.WinForms.Guna2Button btn_Program;
        private Guna.UI2.WinForms.Guna2Button btn_Area;
        private Guna.UI2.WinForms.Guna2Button btn_Weight;
        private Guna.UI2.WinForms.Guna2Button btn_Temp;
        private Guna.UI2.WinForms.Guna2Button btn_BMI;
        private System.Windows.Forms.Label label1;
        private Guna.UI2.WinForms.Guna2Button guna2Button7;
        private Guna.UI2.WinForms.Guna2Elipse Elipse_Data;
        private Guna.UI2.WinForms.Guna2Elipse Elipse_Prog;
        private Guna.UI2.WinForms.Guna2Elipse Elipse_BMI;
        private Guna.UI2.WinForms.Guna2Elipse Elipse_temp;
        private Guna.UI2.WinForms.Guna2Elipse Elipse_weight;
        private Guna.UI2.WinForms.Guna2Elipse Elipse_Area;
        private Calculators.uC_tempCal uC_tempCal1;
        private Calculators.uC_programmer uC_programmer1;
        private Calculators.uC_BMIcal uC_BMIcal1;
        private Calculators.uC_weightCal uC_weightCal1;
        private Calculators.uC_dataCal uC_dataCal1;
        private Calculators.uC_AreaCal uC_AreaCal1;
    }
}

